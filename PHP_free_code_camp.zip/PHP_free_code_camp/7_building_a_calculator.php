<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <body>
        
    <?php
        /********************_____7_building_a_calculator______*********************/
        echo"********************_____7_building_a_calculator______*********************";
    ?>
            <form action="7_building_a_calculator.php" method="get">
            <input type="number" name="num1">
            <br>
            <input type="number" name="num2">
            <input type="submit">
            <br>
            </form>
        Sum : <?php
                echo $_GET["num1"] + $_GET["num2"];
                echo"<br>";
        ?>  
                Difference : <?php
                echo $_GET["num1"] - $_GET["num2"];
                echo"<br>";
        ?> 
                Product : <?php
                echo $_GET["num1"] * $_GET["num2"];
                echo"<br>";
        ?> 
                Quotient : <?php
                echo $_GET["num1"] / $_GET["num2"];
                echo"<br>";
        ?>  
                Remainder : <?php
                echo $_GET["num1"] % $_GET["num2"];
                echo"<br>";
        ?>    

<!--***************************************************************-->    
    </body>
</html>