<!DOCTYPE html>
<html>
<body>

<?php
class Book {
  // Properties
    var $title;
    var $author;
    private $pages;

    function __construct($aTitle,$aAuthor,$aPages){
        $this->title = $aTitle;   //$this keyword is for referring to the currently created object in php
        $this->author = $aAuthor;
        $this->pages = $aPages;
        echo "New book created<br>";
    }
    function bigBook(){
        if($this->pages >=300)return "true";
        return "false";
    }
    function getPages(){
        return $this->pages;
    }
    function setPages($pages){
        $this->pages = $pages;
    }
}

/*without constructor
$book1 = new Book();
$book1->title = "Harry Potter";
$book1->author = "JK Rowling";
$book1->pages=400;

$book2 = new Book();
$book2->title = "Percy Jackson";
$book2->author = "Rick Riordan";
$book2->pages=400;
*/

//with constructor
$book1 = new Book("Harry Potter","JK Rowling",400);
//$book1->pages = 500;  //error (cannot access private property ->if $pages is private)
//but , with getter and setter, we can access even private attributes
echo $book1->getPages()."<br>"; //400
echo $book1->setPages(500)."<br>";
echo $book1->getPages()."<br>"; //500

$book2 = new Book("Percy Jackson","Rick Riordan",400);

echo $book1->title."<br>";   //->blank if pages is not there
echo $book1->bigBook();      //object function
?>
 
</body>
</html>