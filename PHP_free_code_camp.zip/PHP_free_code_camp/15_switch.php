<!DOCTYPE html>
<html>
<body>

<?php
echo"**********************15_switch***************************<br>";
$favcolor = "red";

switch ($favcolor) {
  case "red":
    echo "Your favorite color is red!";
    break;
  case "blue":
    echo "Your favorite color is blue!";
    break;
  case "green":
    echo "Your favorite color is green!";
    break;
  default:
    echo "Your favorite color is neither red, blue, nor green!";
}
echo"<br>";
?>

<?php  
echo"**********************16_while***************************<br>";
$x = 0;
 
while($x <= 100) {
  echo "The number is: $x <br>";
  $x+=10;
}
?> 

<?php 
echo"**********************17_for**************************<br>"; 
for ($x = 0; $x <= 100; $x+=10) {
  echo "The number is: $x <br>";
}
?>  

<?php 
echo"**********************18_include**************************<br>"; 
?>
<?php include "header.html" ?>
<?php include "footer.html" ?>
<?php include "4_strings.php" ?> 
</body>
</html>
