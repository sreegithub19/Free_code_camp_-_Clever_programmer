<?php

echo(
/*************************_________1_Intro_________************/   
'<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <p>********************_____1_Intro______*********************</p>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>
        <h1>Hello folks!</h1>
        <p>There you go!</p>
        <hr>
        <p>PHP is fun!</p>
        <hr>
    </body>
</html>');

/********************_____2_Variables______*********************/
echo"********************_____2_Variables______*********************";
echo "<h3>Spanish, Italian and Portuguese are fun!</h3>";
$age=21;
echo "My age is $age years old";
echo"<br>";
$age = $age -2;
echo"My age is $age years old";
echo"<br>";

/********************_____3_Data_types______*********************/
echo"********************_____3_Data_types______*********************";
echo "<h3>Data types in PHP: string, integer, float, boolean, null</h3>";
$age= "21";    //string
$wno = -22;      //whole number (integer)
$dno = -22.564;  //decimal number(float)
$is_bool = true;    //boolean
echo($age + $wno + $dno + $is_bool);  // -22.564
echo"<br>";
echo"$age + $wno + $dno + $is_bool";  // 21 + -22 + -22.564 + 1
$ert = null;
echo($ert);         //blank
?>