<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <body>
        
    <?php
        /********************_____6_Getting_user_input______*********************/
        echo"********************_____6_Getting_user_input______*********************";
    ?>
            <form action="6_getting_user_input.php" method="get">
            Name: <input type="text" name="username">
            <br>
            Age: <input type="number" name="age">
            <input type="submit">
            </form>
            <br>
                Your name is: <?php echo $_GET["username"] ?>
            <br>
                Your age is: <?php echo $_GET["age"] ?>
    </body>
</html>