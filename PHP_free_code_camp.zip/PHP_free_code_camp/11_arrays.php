<html>
<head></head>
<body>
    <?php
    echo"<br>*************-----11_arrays---------****************<br>";
        $friends = array("Kevin","Karen","Oscar","Jinny",1,34.54,false,null);
        echo $friends[0]."<br>";
        echo $friends[1]."<br>";          //retrieve
        $friends[1] = "Melon";           //replace
        echo $friends[1]."<br>";
        $friends[10] = "Menon";
       // echo $friends[8]."<br>";     //--> shows undefined
        echo count($friends);         //length of array(shows 9)
    ?>
<!------------------------------------------------------------------------->
<?php
    echo"<br>*************-----12_checkboxes---------****************<br>";
?>
    <form action="11_arrays.php" method="post">
    Apples:<input type="checkbox" name="fruits[]" value="apples">
    Pears:<input type="checkbox" name="fruits[]" value="pears">
    Oranges:<input type="checkbox" name="fruits[]" value="oranges">
    Mangoes:<input type="checkbox" name="fruits[]" value="mangoes">
    <input type="submit">
    </form>

<?php
    $fruits = $_POST["fruits"];;
    echo $fruits[1]."<br>";  //prints the second item from the selected list of items
  //  echo $fruits[-1]."<br>";        -> undefined in php
    echo $fruits[count($fruits)-2];
?>
<!------------------------------------------------------------------------->
<?php
    echo"<br>*************-----13_associative_arrays---------****************<br>";
?>

    <form action="11_arrays.php" method="post">
   <input type="text" name="student" >
    <input type="submit">
    </form>

<?php
    $grades = array("Jim"=>"A+","Pam"=>"A+", "Oscar"=>"C+");
    //keys should be unique
    $grades["Jim"]="F";
    echo count($grades)."<br>";
    $keys = array_keys( $grades );     
echo "The keys array: "; 
print_r($keys);  //Array ( [0] => Jim [1] => Pam [2] => Oscar )
echo"<br>";
// Getting the size of the sample array 
$size = sizeof($grades);      
//Accessing elements of $arr using 
//integer index using $x 
echo "The elements of the sample array: "."<br>"; 
for($x = 0; $x < $size; $x++ ) { 
    echo "key: ". $keys[$x] . ", value: " 
            . $grades[$keys[$x]] . "<br>"; 
}
echo $grades[$_POST["student"]];  //type the key to get the value
?>

</body>
</html>