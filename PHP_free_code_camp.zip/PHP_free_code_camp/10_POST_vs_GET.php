<html>
<head></head>
<body>
<?php
        /********************_____10_POST_vs_GET______*********************/
        echo"********************_____10_POST_vs_GET______*********************";
?>
            <form action="10_POST_vs_GET.php" method="post">
                Username:<input type="name" name="name">
                Password:<input type="password" name="password">
            <input type="submit">
            <br><br>
            </form>
<?php
                

?>
</body>
</html>