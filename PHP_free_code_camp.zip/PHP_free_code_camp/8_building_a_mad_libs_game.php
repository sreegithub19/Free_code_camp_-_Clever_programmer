<html>
<head></head>
<body>
<?php
        /********************_____8_building_a_mad_libs_game______*********************/
        echo"********************_____8_building_a_mad_libs_game______*********************";
?>
            <form action="8_building_a_mad_libs_game.php" method="get">
            Color:<input type="text" name="Color"><br>
            Color1:<input type="text" name="Color1"><br>
            Color2:<input type="text" name="Color2"><br>
            <input type="submit">
            <br><br>
            </form>
<?php
            $_color = $_GET["Color"];
            $_color1 = $_GET["Color1"];
            $_color2 = $_GET["Color2"];
            echo"Hi<br>";   
            echo"Roses are $_color <br>";
            echo"Lilies are $_color1 <br>";
            echo"Tulips are $_color2<br>";

?>
</body>
</html>


<!--
        9_URL_Parameters:
        GET method - 
        Pass the parmeters of the form in the URL itself; adv - the page can be bookmarked for future use; info can be stored in the URL
        disadv - not secure, anyone can modify the URL
                http://localhost/php_free_code_camp/6_getting_user_input.php?username=Sreedhar_K&age=23

        POST method - 
        the input parameters and corresponding values are not displayed in the URL
        So, more secure
        