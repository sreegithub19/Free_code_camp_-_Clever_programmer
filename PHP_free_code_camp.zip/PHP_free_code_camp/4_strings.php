<?php

/********************_____4_Strings______*********************/
echo"********************_____4_Strings______*********************";
echo"<br>";
$clause = "COME on everyone";
$phrase = " let's get_going!";
echo strtolower($clause).strtoupper($phrase);
echo"<br><br>";
echo strlen($clause);
echo"<br>";
echo $clause[0];
echo"<br>";
echo "kind"[0];
echo"<br>";
$clause[1]="x";
echo $clause;
echo"<br>";
echo str_replace("everyone","everybody",$clause);
//echo $clause;
echo"<br>";
echo substr($phrase,8,3);
echo"<br>";

/********************_____5_Working_with_numbers______*********************/
echo"********************_____5_Working_with_numbers______*********************";
echo"<br>";
echo -34.5647;
echo"<br>";
echo"stupefy in<br>harry potter"."<br>";
echo 5/9;
echo"<br>";
echo 5%9;
echo"<br>";
echo 5+9;
echo"<br>";
echo 5-9;
echo"<br>";
$num=9;
echo $num++;
echo"<br>";
echo ++$num."  ".(float)"99";
echo"<br>";
echo abs(-34.5)."<br>".sqrt(44)."  ".pow(2,0.5)."  ".max(2,3)."  ".min(2,3);
echo "<br>".ceil(-34.5)."<br>".floor(44.765)."  ";
echo"<br>";


?>