<!DOCTYPE html>
<html>
    <body>     
    <?php
        /********************_____14_functions,if_else______*********************/
        echo"********************_____14_functions,if_else______*********************<br>";
        function say($name){
            echo" Hi cutie ".((int)$name*(int)$name*(int)$name)."<br>";
        }
        /*say("Sweety");
        say("Sweety1");
        say("Sweety2");   */
        say("-4");

        $isMale = true;
        $isTall = false;
        if($isMale && $isTall){
            echo "You are adult male";
        }else if($isMale && !$isTall){echo "You are short male";}
        else{echo"you are female";}
        echo"<br>";
   ?>

<?php
        /********************_____15_building_a_better_calculator______*********************/
        echo"********************_____15_building_a_better_calculator______*********************";
    ?>
            <form action="14_functions.php" method="post">
            <input type="number" step=0.001 name="num1"> 
            <!-- step indicates that the input of at most
            3 decimal places is considered  -->
            <br>
            <input type="number" name="num2">
            <br>
            <input type="string" name="op">
            <input type="submit">
            <br>
            </form>
                <?php
                if($_POST["op"]=="+"){
                echo $_POST["num1"] + $_POST["num2"];
                echo"<br>";
                }
                elseif($_POST["op"]=="-"){
                    echo $_POST["num1"] - $_POST["num2"];
                    echo"<br>";
                    }
                elseif($_POST["op"]=="*"){
                    echo $_POST["num1"] * $_POST["num2"];
                    echo"<br>";
                    }
                elseif($_POST["op"]=="/"){
                    echo $_POST["num1"] / $_POST["num2"];
                    echo"<br>";
                    }
                else {echo"Invalid operator";echo"<br>";}
                ?>    
    </body>
</html>